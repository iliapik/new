
import React, { useState } from 'react';
import StackGame from './StackGame';
import UIOverlay from './UIOverlay';
import { GameStatus, Difficulty } from '../types';
import { STACKER_INCREMENT } from '../constants';

interface StackGameContainerProps {
  balance: number;
  onWin: (amount: number) => void;
  onLose: (amount: number) => void;
  onBack: () => void;
}

const StackGameContainer: React.FC<StackGameContainerProps> = ({ balance, onWin, onLose, onBack }) => {
  const [status, setStatus] = useState<GameStatus>('idle');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [currentBet, setCurrentBet] = useState(0);
  const [level, setLevel] = useState(0);
  const [musicVolume, setMusicVolume] = useState(40);

  const potentialWinnings = currentBet * (1 + (Math.max(0, level - 3) * STACKER_INCREMENT));

  const handleConfirmBet = (amount: number, diff: Difficulty) => {
    onLose(amount);
    setCurrentBet(amount);
    setDifficulty(diff);
    setLevel(0);
    setStatus('playing');
  };

  const handlePlaceBlock = (success: boolean, nextLevel: number) => {
    if (success) {
      setLevel(nextLevel);
    }
  };

  const handleGameOver = () => {
    setStatus('gameover');
  };

  const handleCollect = () => {
    onWin(potentialWinnings);
    setStatus('victory');
  };

  const handleRestart = () => {
    setStatus('idle');
  };

  return (
    <div className="w-full h-full relative">
      <StackGame 
        status={status}
        difficulty={difficulty}
        level={level}
        onPlaceBlock={handlePlaceBlock}
        onGameOver={handleGameOver}
      />
      <UIOverlay 
        balance={balance}
        currentBet={currentBet}
        potentialWinnings={potentialWinnings}
        level={level}
        status={status}
        difficulty={difficulty}
        musicVolume={musicVolume}
        setMusicVolume={setMusicVolume}
        onStartBetting={() => setStatus('betting')}
        onConfirmBet={handleConfirmBet}
        onCollect={handleCollect}
        onRestart={handleRestart}
        onBackToHub={onBack}
        onRedeemCode={() => false}
      />
    </div>
  );
};

export default StackGameContainer;
