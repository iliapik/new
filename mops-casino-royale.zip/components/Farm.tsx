
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Sprout, Smile, Lock } from 'lucide-react';

interface FarmProps {
  onEarn: () => void;
  onBack: () => void;
}

interface Particle {
  id: number;
  x: number;
  y: number;
}

const DAILY_LIMIT = 1000;

const Farm: React.FC<FarmProps> = ({ onEarn, onBack }) => {
  const [particles, setParticles] = useState<Particle[]>([]);
  const [dailyEarnings, setDailyEarnings] = useState(() => {
    const saved = localStorage.getItem('mops_farm_daily_earnings');
    const lastDate = localStorage.getItem('mops_farm_last_date');
    const today = new Date().toDateString();

    if (lastDate !== today) {
      return 0;
    }
    return saved ? parseInt(saved) : 0;
  });

  useEffect(() => {
    const today = new Date().toDateString();
    localStorage.setItem('mops_farm_daily_earnings', dailyEarnings.toString());
    localStorage.setItem('mops_farm_last_date', today);
  }, [dailyEarnings]);

  const handleClick = (e: React.MouseEvent | React.TouchEvent) => {
    if (dailyEarnings >= DAILY_LIMIT) return;

    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;

    const id = Date.now();
    setParticles(prev => [...prev, { id, x: clientX, y: clientY }]);
    
    setDailyEarnings(prev => prev + 1);
    onEarn();

    setTimeout(() => {
      setParticles(prev => prev.filter(p => p.id !== id));
    }, 1000);
  };

  const isLimitReached = dailyEarnings >= DAILY_LIMIT;

  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-6 bg-[#0f172a] overflow-hidden relative">
      <button onClick={onBack} className="absolute top-6 left-6 flex items-center gap-2 text-slate-400 hover:text-white transition-colors z-50">
        <ArrowLeft className="w-5 h-5" /> Back to Hub
      </button>

      <div className="absolute inset-0 opacity-10 pointer-events-none">
         <div className="absolute top-20 left-10 text-lime-500 animate-float"><Sprout className="w-12 h-12" /></div>
         <div className="absolute bottom-20 right-20 text-lime-600 animate-float" style={{ animationDelay: '1s' }}><Sprout className="w-16 h-16" /></div>
      </div>

      <div className="text-center mb-12 relative z-10">
        <div className="inline-flex items-center gap-2 bg-lime-500/10 px-4 py-2 rounded-full border border-lime-500/20 mb-4">
          <Sprout className="w-4 h-4 text-lime-500" />
          <span className="text-lime-500 text-[10px] font-black uppercase tracking-[0.2em]">Manual Liquidity Farm</span>
        </div>
        <h1 className="text-5xl font-black text-white italic tracking-tighter uppercase mb-2">MOPS <span className="text-lime-500">FARM</span></h1>
        <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">TAP TO EARN • 1 MOPS PER CLICK</p>
      </div>

      <button 
        onMouseDown={handleClick}
        disabled={isLimitReached}
        className={`relative group transition-all active:scale-95 touch-none ${isLimitReached ? 'cursor-not-allowed opacity-80' : ''}`}
      >
        <div className={`absolute -inset-10 rounded-full blur-3xl transition-all ${isLimitReached ? 'bg-rose-500/10' : 'bg-lime-500/20 group-hover:bg-lime-500/30 animate-pulse'}`} />
        
        <div className={`relative w-64 h-64 sm:w-80 sm:h-80 bg-gradient-to-b rounded-full border-8 shadow-2xl flex items-center justify-center overflow-hidden transition-colors ${isLimitReached ? 'from-slate-600 to-slate-800 border-slate-900 grayscale' : 'from-yellow-300 to-amber-600 border-amber-800'}`}>
          <div className="absolute inset-2 rounded-full border-4 border-white/10 border-dashed animate-[spin_20s_linear_infinite]" />
          
          <div className="relative flex flex-col items-center">
             <div className="w-32 h-32 sm:w-40 sm:h-40 bg-[#c6a074] rounded-[3rem] border-8 border-[#5d4037] shadow-lg relative flex flex-col items-center justify-center p-4">
                <div className="absolute -top-4 -left-6 w-16 h-20 bg-[#5d4037] rounded-full rotate-[-45deg]" />
                <div className="absolute -top-4 -right-6 w-16 h-20 bg-[#5d4037] rounded-full rotate-[45deg]" />
                
                <div className="flex gap-8 mb-4">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 bg-white rounded-full relative">
                    <div className={`absolute top-1 right-1 w-4 h-4 bg-black rounded-full transition-all ${isLimitReached ? 'h-1 top-2' : ''}`} />
                  </div>
                  <div className="w-8 h-8 sm:w-10 sm:h-10 bg-white rounded-full relative">
                    <div className={`absolute top-1 left-1 w-4 h-4 bg-black rounded-full transition-all ${isLimitReached ? 'h-1 top-2' : ''}`} />
                  </div>
                </div>
                
                <div className="w-20 h-16 sm:w-24 sm:h-20 bg-[#5d4037] rounded-3xl flex flex-col items-center justify-center gap-1">
                   <div className="w-6 h-4 sm:w-8 sm:h-6 bg-black rounded-full" />
                   <div className="flex gap-1">
                     {isLimitReached ? (
                       <Smile className="w-4 h-4 text-slate-400 fill-current opacity-50" />
                     ) : (
                       <Smile className="w-4 h-4 text-rose-500 fill-current" />
                     )}
                   </div>
                </div>

                <div className="absolute top-2 text-[#5d4037] font-black text-xl">M</div>
             </div>
          </div>

          {isLimitReached && (
             <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-[2px] flex items-center justify-center">
                <Lock className="w-20 h-20 text-white/20" />
             </div>
          )}

          <div className="absolute bottom-8 text-amber-900 font-black text-2xl tracking-tighter uppercase italic drop-shadow-sm">MOPSCoin</div>
        </div>
      </button>

      <div className="mt-12 flex flex-col items-center gap-4">
        <div className="text-slate-500 font-mono text-xl font-bold bg-slate-900/50 px-8 py-3 rounded-2xl border border-slate-800 flex items-center gap-3">
          DAILY LIMIT: 
          <span className={`transition-colors ${isLimitReached ? 'text-rose-500' : 'text-lime-500'}`}>
            {dailyEarnings.toLocaleString()}/1,000 MOPS
          </span>
        </div>
        
        {isLimitReached && (
          <div className="text-[10px] font-black uppercase text-rose-500 tracking-[0.2em] animate-pulse">
            Limit reached for today. Come back tomorrow!
          </div>
        )}
      </div>

      {particles.map(p => (
        <div 
          key={p.id}
          className="fixed pointer-events-none text-lime-400 font-black text-2xl animate-out fade-out slide-out-to-top-20 duration-1000 z-[100] flex items-center gap-1"
          style={{ left: p.x, top: p.y - 40 }}
        >
          +1 <Smile className="w-5 h-5" />
        </div>
      ))}

      <footer className="mt-12 text-center opacity-40">
        <div className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500 flex items-center justify-center gap-2">
          <Smile className="w-3 h-3" /> Honest MOPS Work Policy
        </div>
      </footer>
    </div>
  );
};

export default Farm;
